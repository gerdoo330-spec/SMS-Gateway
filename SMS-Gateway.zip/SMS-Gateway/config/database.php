<?php
declare(strict_types=1);

// تنظیمات اتصال دیتابیس محیط توسعه XAMPP
// اگر برای MySQL رمز گذاشته‌ای، مقدار password را تغییر بده.
return [
    'host' => '127.0.0.1',
    'database' => 'sms_gateway',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
